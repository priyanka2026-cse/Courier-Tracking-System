var STAT=["Booked","Dispatched","In Transit","Out for Delivery","Delivered","Returned"];
var ROLES={customer:"Customer",staff:"Staff",agent:"Delivery agent",admin:"Admin"};
var TABS={
 customer:[["track","Track"],["book","Book courier"],["mine","My parcels"],["profile","Profile"]],
 staff:[["track","Track"],["book","Register courier"],["ship","Shipments"],["profile","Profile"]],
 agent:[["track","Track"],["deliv","My deliveries"],["profile","Profile"]],
 admin:[["track","Track"],["book","Register courier"],["ship","Shipments"],["deliv","Deliveries"],["users","Users"],["reports","Reports"],["profile","Profile"]]};
var KEY="swifttrack_v2",UKEY="swifttrack_users_v2",db=[],users=[],user=null,reg=false;
function $(i){return document.getElementById(i)}
function esc(s){var d=document.createElement("div");d.textContent=s==null?"":s;return d.innerHTML}
function fmt(t){return new Date(t).toLocaleString([],{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"})}
function cur(x){return x.ev[0]}
function find(id){id=String(id).trim().toUpperCase();return db.find(function(x){return x.id===id})}
function now(h){return new Date(Date.now()-h*3600000).toISOString()}
function msg(id,t,ok){var e=$(id);e.className=ok?"ok":"msg";e.textContent=t}
function ld(k,f){try{var v=localStorage.getItem(k);if(v)return JSON.parse(v)}catch(e){}return f()}
function save(){try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){}}
function saveU(){try{localStorage.setItem(UKEY,JSON.stringify(users))}catch(e){}}
function seedU(){return[{u:"admin",p:"admin123",role:"admin",name:"Admin"},{u:"staff1",p:"staff123",role:"staff",name:"Staff One"},{u:"agent1",p:"agent123",role:"agent",name:"Agent One"},{u:"customer",p:"cust123",role:"customer",name:"Customer"}]}
function seedS(){return[
{id:"ST1001",cust:"customer",sender:"Priya Textiles",receiver:"Arun Kumar",from:"Tiruchirappalli",to:"Chennai",addr:"12 Anna Nagar, Chennai",parcel:"Clothes",wt:2,agent:"agent1",sched:"",by:"staff1",ev:[{s:2,l:"Chennai Hub",t:now(3)},{s:1,l:"Tiruchirappalli Depot",t:now(20)},{s:0,l:"Tiruchirappalli",t:now(30)}]},
{id:"ST1002",cust:"customer",sender:"BookNest",receiver:"Meena S",from:"Madurai",to:"Bengaluru",addr:"5 MG Road, Bengaluru",parcel:"Books",wt:3.5,agent:"agent1",sched:"",by:"staff1",ev:[{s:4,l:"Bengaluru",t:now(2)},{s:3,l:"Bengaluru Local Hub",t:now(9)},{s:2,l:"Hosur Transit",t:now(22)},{s:1,l:"Madurai Depot",t:now(40)},{s:0,l:"Madurai",t:now(46)}]}]}

/* ---------- Parcel tracking module ---------- */
function show(x){
  var st=cur(x).s,pos=st==5?-1:st;
  var steps=STAT.slice(0,5).map(function(n,i){return '<div class="step'+(i<=pos?' on':'')+(i<pos?' on2':'')+'"><i></i>'+n+'</div>'}).join("");
  var tl=x.ev.map(function(e){return '<li><strong>'+STAT[e.s]+'</strong><br><small>'+esc(e.l)+' · '+fmt(e.t)+'</small></li>'}).join("");
  $("result").innerHTML='<div class="card"><div class="head"><div><div class="id">'+esc(x.id)+'</div><small style="color:var(--mute)">Last seen at '+esc(cur(x).l)+'</small></div><span class="badge'+(st==4?' done':'')+'">'+STAT[st]+'</span></div>'+
  '<div class="route"><div><small>From</small>'+esc(x.from)+'</div><div style="text-align:right"><small>To</small>'+esc(x.to)+'</div></div>'+
  '<div class="steps">'+steps+'</div><ul class="tl">'+tl+'</ul>'+
  '<p style="color:var(--mute);font-size:.85rem;margin:6px 0 0">Sent by '+esc(x.sender)+' to '+esc(x.receiver)+(x.agent?' · Agent: '+esc(x.agent):'')+(x.sched?' · Delivery date: '+esc(x.sched):'')+'</p></div>';
}
function track(id){
  $("err").textContent="";$("result").innerHTML="";
  if(!String(id).trim()){$("err").textContent="Enter a tracking ID to continue.";return}
  var x=find(id);
  if(!x){$("err").textContent="No shipment found for "+String(id).trim().toUpperCase()+". Check the ID and try again.";return}
  show(x);
}

/* ---------- Customer + courier management modules ---------- */
function book(){
  var f=["bs","br","bo","bd","ba","bp"].map(function(i){return $(i).value.trim()});
  var cust=user.role==="customer"?user.u:$("bc").value.trim();
  if(f.some(function(a){return !a})){msg("bm","Fill in sender, receiver, cities, address and parcel details.");return}
  if(!users.some(function(u){return u.u===cust&&u.role==="customer"})){msg("bm","Customer username not found. Create the account in Users first.");return}
  var n=Math.max.apply(null,db.map(function(x){return +x.id.slice(2)}).concat(1000))+1,id="ST"+n;
  db.unshift({id:id,cust:cust,sender:f[0],receiver:f[1],from:f[2],to:f[3],addr:f[4],parcel:f[5],wt:+$("bw").value||1,agent:"",sched:"",by:user.u,ev:[{s:0,l:f[2],t:new Date().toISOString()}]});
  save();msg("bm","Booked! Tracking ID: "+id,1);
  ["bs","br","bo","bd","ba","bp"].forEach(function(i){$(i).value=""});
}
function rows(list,agent){
  return list.map(function(x){return '<tr><td><button class="link" data-t="'+x.id+'">'+x.id+'</button></td><td>'+esc(x.from)+' → '+esc(x.to)+'</td><td>'+STAT[cur(x).s]+'</td>'+(agent?'<td>'+esc(x.agent||"Unassigned")+'</td>':'')+'</tr>'}).join("")||'<tr><td colspan="4">Nothing here yet.</td></tr>';
}
function rShip(){
  $("uid").innerHTML=db.map(function(x){return '<option>'+x.id+'</option>'}).join("");
  $("ust").innerHTML=STAT.map(function(n,i){return '<option value="'+i+'">'+n+'</option>'}).join("");
  $("ua").innerHTML='<option value="">Keep current</option>'+users.filter(function(u){return u.role==="agent"}).map(function(u){return '<option value="'+esc(u.u)+'">'+esc(u.name||u.u)+' ('+esc(u.u)+')</option>'}).join("");
  $("all").innerHTML=rows(db,1);
}
function setStatus(x,s,l){x.ev.unshift({s:s,l:l,t:new Date().toISOString()})}
function upd(){
  var x=find($("uid").value),l=$("uloc").value.trim();
  if(!x||!l){msg("um","Pick a shipment and enter the current location.");return}
  setStatus(x,+$("ust").value,l);
  if($("ua").value)x.agent=$("ua").value;
  if($("usd").value)x.sched=$("usd").value;
  save();rShip();$("uid").value=x.id;$("uloc").value="";msg("um","Updated "+x.id,1);
}

/* ---------- Delivery management module ---------- */
function rDeliv(){
  var l=db.filter(function(x){return x.agent&&(user.role==="admin"||x.agent===user.u)});
  $("dl").innerHTML=l.map(function(x){
    var s=cur(x).s,open=s<4;
    return '<div class="card"><div class="head"><div><div class="id">'+x.id+'</div><small style="color:var(--mute)">'+esc(x.receiver)+' · '+esc(x.addr)+'</small></div><span class="badge'+(s==4?' done':'')+'">'+STAT[s]+'</span></div>'+
    '<p style="margin:10px 0 4px"><small>Parcel: '+esc(x.parcel)+' ('+x.wt+' kg)'+(user.role==="admin"?' · Agent: '+esc(x.agent):'')+'</small></p>'+
    (open?'<label>Delivery date</label><input type="date" data-sd="'+x.id+'" value="'+esc(x.sched)+'" style="max-width:220px"><p>'+
    '<button class="sm" data-sid="'+x.id+'" data-st="3">Out for delivery</button><button class="sm go" data-sid="'+x.id+'" data-st="4">Delivered</button><button class="sm" data-sid="'+x.id+'" data-st="5">Returned</button></p>':'<p style="margin:6px 0 0"><small>'+(x.sched?'Date: '+esc(x.sched):'Closed')+'</small></p>')+'</div>'}).join("")||'<div class="card">No parcels assigned yet.</div>';
}

/* ---------- User and role management module ---------- */
function rUsers(){
  $("ul").innerHTML=users.map(function(u){return '<tr><td>'+esc(u.name||u.u)+'</td><td>'+esc(u.u)+'</td><td>'+ROLES[u.role]+'</td><td>'+(u.u===user.u?'<small>you</small>':'<button class="sm" data-del="'+esc(u.u)+'">Delete</button>')+'</td></tr>'}).join("");
}
function addUser(){
  var n=$("nn").value.trim(),u=$("nu").value.trim(),p=$("np").value;
  if(!n||!u||p.length<4){msg("nm","Enter name, username and a password of 4+ characters.");return}
  if(users.some(function(x){return x.u.toLowerCase()===u.toLowerCase()})){msg("nm","That username is taken.");return}
  users.push({u:u,p:p,role:$("nr").value,name:n});saveU();rUsers();msg("nm","Account created for "+u,1);
  ["nn","nu","np"].forEach(function(i){$(i).value=""});
}
function rProf(){$("pn").value=user.name||"";$("pp").value=user.phone||"";$("pw").value="";$("pm").textContent=""}
function saveProf(){
  var n=$("pn").value.trim(),w=$("pw").value;
  if(!n){msg("pm","Name can't be empty.");return}
  if(w&&w.length<4){msg("pm","Password needs 4+ characters.");return}
  user.name=n;user.phone=$("pp").value.trim();if(w)user.p=w;saveU();msg("pm","Profile saved.",1);
}

/* ---------- Reports module ---------- */
function tiles(a){return '<div class="tiles">'+a.map(function(t){return '<div class="tile"><b>'+t[1]+'</b>'+t[0]+'</div>'}).join("")+'</div>'}
function rRep(){
  var cut=Date.now()-(+$("rp").value)*864e5,S=function(x){return cur(x).s};
  var nb=db.filter(function(x){return new Date(x.ev[x.ev.length-1].t)>=cut}).length;
  var del=db.filter(function(x){return S(x)==4}).length,ret=db.filter(function(x){return S(x)==5}).length;
  var h='<h3>Courier booking report</h3>'+tiles([["Bookings in period",nb],["All shipments",db.length]]);
  h+='<h3>Delivery report</h3>'+tiles([["Delivered",del],["Pending",db.length-del-ret],["Returned",ret]]);
  var cs={};db.forEach(function(x){var c=cs[x.cust]=cs[x.cust]||{n:0,d:0};c.n++;if(S(x)==4)c.d++});
  h+='<h3>Customer report</h3><div class="card scroll"><table><thead><tr><th>Customer</th><th>Bookings</th><th>Delivered</th></tr></thead><tbody>'+Object.keys(cs).map(function(k){return '<tr><td>'+esc(k)+'</td><td>'+cs[k].n+'</td><td>'+cs[k].d+'</td></tr>'}).join("")+'</tbody></table></div>';
  h+='<h3>Performance report</h3><div class="card scroll"><table><thead><tr><th>Name</th><th>Role</th><th>Handled</th><th>Delivered</th><th>Success</th></tr></thead><tbody>'+users.filter(function(u){return u.role==="agent"||u.role==="staff"}).map(function(u){
    var m=db.filter(function(x){return u.role==="agent"?x.agent===u.u:x.by===u.u}),d=m.filter(function(x){return S(x)==4}).length;
    return '<tr><td>'+esc(u.name||u.u)+'</td><td>'+ROLES[u.role]+'</td><td>'+m.length+'</td><td>'+(u.role==="agent"?d:"-")+'</td><td>'+(u.role==="agent"&&m.length?Math.round(d/m.length*100)+"%":"-")+'</td></tr>'}).join("")+'</tbody></table></div>';
  $("rep").innerHTML=h;
}

/* ---------- Navigation, login, roles ---------- */
function go(v){
  if(!user)return;
  if(!TABS[user.role].some(function(t){return t[0]===v}))v="track";
  document.querySelectorAll("main>section").forEach(function(s){s.classList.add("hide")});
  $("v-"+v).classList.remove("hide");
  document.querySelectorAll("#nav button[data-v]").forEach(function(b){b.classList.toggle("on",b.dataset.v===v)});
  if(v==="track"){$("demo").innerHTML=db.slice(0,4).map(function(x){return '<button data-t="'+x.id+'">'+x.id+'</button>'}).join("")}
  if(v==="book"){$("bcw").classList.toggle("hide",user.role==="customer");$("bh").textContent=user.role==="customer"?"Book a courier":"Register a courier";$("bm").textContent=""}
  if(v==="mine")$("mine").innerHTML=rows(db.filter(function(x){return x.cust===user.u}));
  if(v==="ship"){rShip();$("um").textContent=""}
  if(v==="deliv")rDeliv();
  if(v==="users"){rUsers();$("nm").textContent=""}
  if(v==="reports")rRep();
  if(v==="profile")rProf();
}
function enter(x){
  user=x;$("login").classList.add("hide");$("hdr").classList.remove("hide");$("lp").value="";$("lerr").textContent="";
  $("nav").innerHTML=TABS[x.role].map(function(t){return '<button data-v="'+t[0]+'">'+t[1]+'</button>'}).join("")+'<span class="who">'+esc(x.name||x.u)+' · '+ROLES[x.role]+'</span><button id="out">Log out</button>';
  go(x.role==="agent"?"deliv":"track");
}
function logout(){
  user=null;$("hdr").classList.add("hide");document.querySelectorAll("main>section").forEach(function(s){s.classList.add("hide")});
  $("login").classList.remove("hide");$("lu").value="";$("result").innerHTML="";$("q").value="";mode(false);
}
function mode(r){reg=r;$("lh").textContent=r?"Create account":"Sign in";$("rolebox").classList.toggle("hide",r);$("lgo").textContent=r?"Create account":"Sign in";$("lsw").textContent=r?"Have an account? Sign in":"New customer? Create an account";$("lerr").textContent=""}
function doLogin(){
  var u=$("lu").value.trim(),p=$("lp").value,e=$("lerr");
  if(!u||!p){e.textContent="Enter your username and password.";return}
  if(reg){
    if(p.length<4){e.textContent="Use a password with at least 4 characters.";return}
    if(users.some(function(x){return x.u.toLowerCase()===u.toLowerCase()})){e.textContent="That username is taken. Pick another.";return}
    var n={u:u,p:p,role:"customer",name:u};users.push(n);saveU();enter(n);return}
  var m=users.find(function(x){return x.u.toLowerCase()===u.toLowerCase()&&x.p===p});
  if(!m){e.textContent="Wrong username or password.";return}
  if(m.role!==$("lr").value){e.textContent="This is a "+ROLES[m.role]+" account. Change 'Login as' to "+ROLES[m.role]+".";return}
  enter(m);
}

/* ---------- Events ---------- */
document.addEventListener("click",function(e){
  var b=e.target.closest("button");if(!b)return;var d=b.dataset;
  if(b.id==="out")logout();
  else if(d.v)go(d.v);
  else if(d.t){go("track");$("q").value=d.t;track(d.t)}
  else if(d.st){var x=find(d.sid),s=+d.st;if(x){setStatus(x,s,s==3?x.to+" local hub":s==4?x.to+" (delivered)":x.to+" (returned)");save();rDeliv()}}
  else if(d.del){users=users.filter(function(u){return u.u!==d.del});saveU();rUsers()}
});
document.addEventListener("change",function(e){
  var id=e.target.dataset.sd;if(id){var x=find(id);if(x){x.sched=e.target.value;save()}}
  if(e.target.id==="rp")rRep();
});
$("go").onclick=function(){track($("q").value)};
$("q").onkeydown=function(e){if(e.key==="Enter")track($("q").value)};
$("bgo").onclick=book;$("upd").onclick=upd;$("ngo").onclick=addUser;$("pgo").onclick=saveProf;
$("lgo").onclick=doLogin;$("lsw").onclick=function(){mode(!reg)};
$("lp").onkeydown=function(e){if(e.key==="Enter")doLogin()};
db=ld(KEY,seedS);users=ld(UKEY,seedU);
